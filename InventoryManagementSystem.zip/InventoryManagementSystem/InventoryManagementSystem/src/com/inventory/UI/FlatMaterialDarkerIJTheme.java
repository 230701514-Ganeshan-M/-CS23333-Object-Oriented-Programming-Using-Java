package com.inventory.UI;

public class FlatMaterialDarkerIJTheme {

}
